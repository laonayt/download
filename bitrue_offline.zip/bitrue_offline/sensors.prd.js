(function (para) {
  var p = para.sdk_url,
    n = para.name,
    w = window,
    d = document,
    s = "script",
    x = null,
    y = null;
  if (typeof w["sensorsDataAnalytic201505"] !== "undefined") {
    return false;
  }
  w["sensorsDataAnalytic201505"] = n;
  w[n] =
    w[n] ||
    function (a) {
      return function () {
        (w[n]._q = w[n]._q || []).push([a, arguments]);
      };
    };
  var ifs = [
    "track",
    "quick",
    "register",
    "registerPage",
    "registerOnce",
    "trackSignup",
    "trackAbtest",
    "setProfile",
    "setOnceProfile",
    "appendProfile",
    "incrementProfile",
    "deleteProfile",
    "unsetProfile",
    "identify",
    "login",
    "logout",
    "trackLink",
    "clearAllRegister",
    "getAppStatus",
    "setItem",
    "deleteItem",
  ];
  for (var i = 0; i < ifs.length; i++) {
    w[n][ifs[i]] = w[n].call(null, ifs[i]);
  }
  if (!w[n]._t) {
    (x = d.createElement(s)), (y = d.getElementsByTagName(s)[0]);
    x.async = 1;
    x.src = p;
    x.setAttribute("charset", "UTF-8");
    w[n].para = para;
    y.parentNode.insertBefore(x, y);
  }
})({
  sdk_url: "https://static.bitrue.com/media/sensorsdata.min.js",
  name: "sensors",
  server_url: "https://sensors.bitrue.com:443/sa?project=production",
  heatmap: { scroll_notice_map: "not_collect" },
  is_track_single_page: true,
  use_client_time: true,
  show_log: false,
  send_type: "beacon",
  preset_properties: {
    latest_landing_page: true,
    latest_referrer_host: true,
  },
});
function getCookie(name) {
  try {
    // 构建 Cookie 名称与等号的字符串
    var nameEQ = name + "=";
    // 使用 split 方法将 cookie 字符串分割成数组
    var cookies = document.cookie.split(";");
    for (var i = 0; i < cookies.length; i++) {
      // 去除每个 cookie 字符串的前后空格
      var cookie = cookies[i].replace(/^\s+|\s+$/g, "");
      // 检查 Cookie 是否以指定的名称开头
      if (cookie.indexOf(nameEQ) === 0) {
        // 返回解码后的 Cookie 值
        return decodeURIComponent(cookie.substring(nameEQ.length));
      }
    }
  } catch (e) {
    console.error("Error while getting cookie:", e);
  }
  // 如果没有找到指定的 Cookie，返回 null
  return null;
}
var invite_code = getCookie("inviteCode");
var channel_id = getCookie("channelId");
sensors.registerPage({
  current_url: location.href,
  referrer: document.referrer,
  invite_code,
  channel_id,
});
sensors.quick("autoTrack");
